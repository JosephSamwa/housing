from django.urls import path
from . import views

urlpatterns = [
    path('', views.property_list, name='property_list'),
    path('property/<int:property_id>/', views.property_detail, name='property_detail'),
    path('property/<int:property_id>/send-message/', views.send_message, name='send_message'),
    path('property/<int:property_id>/simulate-payment/', views.simulate_payment, name='simulate_payment'),
    path('property/<int:property_id>/initiate-payment/', views.initiate_payment, name='initiate_payment'),
    # Add a path for the M-Pesa callback
    path('mpesa-callback/', views.mpesa_callback, name='mpesa_callback'),
]
